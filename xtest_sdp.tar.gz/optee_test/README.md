# OP-TEE sanity testsuite
This git contains source code for the test suite (xtest) used to test the
OP-TEE project.

All official OP-TEE documentation has moved to http://optee.readthedocs.io. The
information that used to be here in this git can be found under [optee_test].

// OP-TEE core maintainers

[optee_test]: https://optee.readthedocs.io/en/latest/building/gits/optee_test.html
